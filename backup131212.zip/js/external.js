$(function(){
	/* Hide Elements*/
	$("#Three_Mode .animate div").each(function(){
		$(this).hide();
	});
	$("#Three_Mode .description div").each(function(){
		$(this).hide();
	});
	$("#screen").hide();
	$("#Exp_model .animate img").each(function(){
		$(this).hide();
	});
	$("#Exp_model .animate div").hide();
	$("#screen embed").hide();
	
	/* Initial */
	var scrollTop = 0;
	var recipeToggle = true;
	var modelNavPrevStep = 0;
	var currentVid = 1;
	var prevVid = 0;
	
	/* Resize videos*/
	function vidResize(){
		var vidMargin = ($("#Interview .chapter").innerHeight() - $("#Interview .chapter video").height())/2
		$("#Interview .chapter video, #Interview .chapter div").css("margin-top",vidMargin);
	}
	vidResize();
	
	/* Resizing Events */
	$(window).resize(function(){
		vidResize();
	});
	
	/* Calculating Section Heights */
	$("section").each(function(i,elem){
		var id = $(this).attr('id');
		var pos = $(this).position();
		$("#scrollVertical p:nth-of-type(2)").append("#"+id+": "+pos.top+", ");
		////  Add Navi Elements////
		var iplusone = i+1;
		var txt = $("<a></a>").html(iplusone+"<span>"+id+"</span>").attr("href","#"+id);
		$("#navigation").prepend(txt);
	});
	
	/* Scrolling Action*/
	$(window).scroll(function(){
	
		/* 1. Get window position */
		var increment = $(window).scrollTop() - scrollTop;
		scrollTop = $(window).scrollTop();
		//$("#scrollVertical p:nth-of-type(1)").html("Scroll: "+scrollTop+" px, increment : "+increment+" px <br>");
		$("#scrollVertical p:nth-of-type(1)").html("Scroll: "+scrollTop+" px <br>");
		
		/* 2. "#Modes" animation */
		//// h2 fix ////
		if(scrollTop > 9000 && scrollTop < 16200){
			$("#Three_Mode h2").css({"position":"fixed","top":"0","left":"50%","margin-left":"-480px"});
		}else{
			$("#Three_Mode h2").css({"position":"relative","left":"0","margin-left":"0px"});
		}
		
		//// recipe ////
		if(scrollTop > 10200 && scrollTop < 13800){
			if(recipeToggle){
				recipeToggle = false;
				$("#Three_Mode .recipe").fadeIn(1000,function(){
					$(this).fadeOut(4000,function(){
						$(this).text("Recipe").fadeIn(1000);
					})
				});
			}
		}else{
			recipeToggle = true;
			$("#Three_Mode .recipe").stop(true,true).fadeOut(1000,function(){
				$(this).hide().text("Experiment");
			});
		}
		//// recipe_text ////
		if(scrollTop > 10200 && scrollTop < 11400){
			$("#Three_Mode .description div:nth-of-type(1)").fadeIn("slow");
		}else{
			$("#Three_Mode .description div:nth-of-type(1)").fadeOut("slow");
		}
		
		//// activity ////
		if(scrollTop > 11400 && scrollTop < 16200){
			$("#Three_Mode .activity").show();
			$("#Three_Mode .activity div:nth-of-type(1)").fadeIn("slow", function(){
				$("#Three_Mode .activity div:nth-of-type(2)").fadeIn("slow", function(){
					$("#Three_Mode .activity div:nth-of-type(3)").fadeIn("slow");
				});
			});
		}else{
			$("#Three_Mode .activity div").stop(true);
			$("#Three_Mode .activity div").fadeOut("fast");
		}
		//// activity_text ////
		if(scrollTop > 11400 && scrollTop < 12000){
			$("#Three_Mode .description div:nth-of-type(2)").fadeIn("slow",function(){
				$("#Three_Mode .description div:nth-of-type(3)").fadeIn("slow",function(){
					$("#Three_Mode .description div:nth-of-type(4)").fadeIn("slow");
				});
			});
		}else{
			$("#Three_Mode .description div:nth-of-type(2), #Three_Mode .description div:nth-of-type(3), #Three_Mode .description div:nth-of-type(4)").fadeOut("slow");
		}
		//// activity_text_need ////
		if(scrollTop > 12600 && scrollTop < 16200){
			$("#Three_Mode .description div:nth-of-type(5)").fadeIn("slow",function(){
				$("#Three_Mode .description div:nth-of-type(6)").fadeIn("slow",function(){
					$("#Three_Mode .description div:nth-of-type(7)").fadeIn("slow");
				});
			});
		}else{
			$("#Three_Mode .description div:nth-of-type(5), #Three_Mode .description div:nth-of-type(6), #Three_Mode .description div:nth-of-type(7)").fadeOut("slow");
		}
		
		//// arrow ////
		if(scrollTop > 11400 && scrollTop < 13800){
			$("#Three_Mode .arrow").show();
			$("#Three_Mode .arrow div:nth-of-type(1)").fadeIn("fast").animate({top:'60%',left:'22%'},500, function(){
				$("#Three_Mode .arrow div:nth-of-type(2)").fadeIn("fast").animate({top:'69%',left:'54%'},500, function(){
					$("#Three_Mode .arrow div:nth-of-type(3)").fadeIn("fast").animate({top:'43%',left:'54%'},500);
				});
			});
		}else{
			$("#Three_Mode .arrow div").stop(true);
			$("#Three_Mode .arrow div").fadeOut("fast",function(){
				$("#Three_Mode .arrow div:nth-of-type(1)").css({'top':'60%','left':'18%'});
				$("#Three_Mode .arrow div:nth-of-type(2)").css({'top':'73%','left':'57%'});
				$("#Three_Mode .arrow div:nth-of-type(3)").css({'top':'40%','left':'57%'});
			});
		}
		
		//// fork ////
		if(scrollTop > 13800 && scrollTop < 16200){
			$("#Three_Mode .fork").fadeIn("slow");
		}else{
			$("#Three_Mode .fork").fadeOut("slow");
		}
		
		//// share ////
		if(scrollTop > 13800 && scrollTop < 16200){
			$("#Three_Mode .share").show();
			$("#Three_Mode .share div:nth-of-type(1)").fadeIn("fast").animate({top:'35%',left:'40%'},1000, function(){
				$("#Three_Mode .share div:nth-of-type(2)").fadeIn("fast").animate({top:'87%',left:'40%'},1000);
			});
		}else{
			$("#Three_Mode .share div").stop(true);
			$("#Three_Mode .share div").fadeOut("fast",function(){
				$("#Three_Mode .share div:nth-of-type(1)").css({'top':'60%','left':'10%'});
				$("#Three_Mode .share div:nth-of-type(2)").css({'top':'60%','left':'10%'});
			});
		}
						
		//// background image ////
		if(scrollTop > 13800){
			$("#Three_Mode").css("backgroundPosition","0 100%");
		}else{
			$("#Three_Mode").css("backgroundPosition","0 0");
		}
		
		/* 3. Features animation */
		if(scrollTop > 22200 && scrollTop < 28800){
			$("#screen").fadeIn(700);
			if(scrollTop < 22800){
				prevVid = 0;
			}else if(scrollTop >= 22800 && scrollTop < 25200){
				currentVid = 1;
				if(prevVid-currentVid != 0){
					$("#screen embed").hide();
					$("#screen #Landing").show();
					prevVid = currentVid;
				}
			}else if(scrollTop >= 25200 && scrollTop < 27600){
				currentVid = 2;
				if(prevVid-currentVid != 0){
					$("#screen embed").hide();
					$("#screen #Making").show();
					prevVid = currentVid;
				}
			}else if(scrollTop >= 27600 && scrollTop < 28400){
				currentVid = 3;
				if(prevVid-currentVid != 0){
					$("#screen embed").hide();
					$("#screen #Journaling").show();
					prevVid = currentVid;
				}
			}if(scrollTop >= 28400){
				prevVid = 0;
			}
		}else{
			$("#screen embed").hide();
			$("#screen").fadeOut(700);
			//alert(prevVid+""+currentVid)
		}
		
		/* 4. Model animation */
		if(scrollTop >= 46400 && scrollTop < 57600){
			$("#Exp_model h2").css({"position":"fixed","top":"0","left":"50%","margin-left":"-480px"});
			$("#Exp_model .animate div").fadeIn("fast");
			if(scrollTop >= 46400){$("#Exp_model .animate img:nth-of-type(1)").fadeIn("slow")};
			if(scrollTop >= 47800){$("#Exp_model .animate img:nth-of-type(4)").fadeIn("slow")}else{$("#Exp_model .animate img:nth-of-type(4)").stop(true,false).fadeOut("slow")};
			if(scrollTop >= 49200){$("#Exp_model .animate img:nth-of-type(5)").fadeIn("slow")}else{$("#Exp_model .animate img:nth-of-type(5)").stop(true,false).fadeOut("slow")};
			if(scrollTop >= 50600){$("#Exp_model .animate img:nth-of-type(6)").fadeIn("slow")}else{$("#Exp_model .animate img:nth-of-type(6)").stop(true,false).fadeOut("slow")};
			if(scrollTop >= 52000){$("#Exp_model .animate img:nth-of-type(7)").fadeIn("slow")}else{$("#Exp_model .animate img:nth-of-type(7)").stop(true,false).fadeOut("slow")};
			if(scrollTop >= 53400){$("#Exp_model .animate img:nth-of-type(2)").fadeIn("slow")}else{$("#Exp_model .animate img:nth-of-type(2)").stop(true,false).fadeOut("slow")};
			if(scrollTop >= 54800){$("#Exp_model .animate img:nth-of-type(3)").fadeIn("slow")}else{$("#Exp_model .animate img:nth-of-type(3)").stop(true,false).fadeOut("slow")};
			if(scrollTop >= 56200){$("#Exp_model .animate img:nth-of-type(8)").fadeIn("slow",function(){
				$(this).animate({"left":"-15px"}).animate({"left":"0px"});
			})}else{$("#Exp_model .animate img:nth-of-type(8)").stop(true,false).fadeOut("slow")};;
		}else{
			$("#Exp_model h2").css({"position":"relative"}).removeProp("top","left","margin-left");
			$("#Exp_model .animate div").fadeOut("fast");
			$("#Exp_model .animate img").each(function(){
				$(this).stop(true,false).fadeOut("fast");
			});
		};
		
		//// Model Navigation////
		var modelNavPos = [46400,47800,49200,50600,52000,53400,54800,56200,57600];
		for (i=0;i<8;i++){
			(function(j){
				var $a = $("#Exp_model .animate a:nth-of-type("+(j+1)+")");
				$a.click(function(){
					$(window).scrollTop(46400+(j*1400));
				});
			})(i);
		};
		
		//// Model Navigation_swap current////
		var modelNavStep = Math.floor((scrollTop - 46400)/1400);
		if( modelNavPrevStep-modelNavStep != 0 ){
			$("#Exp_model .animate a").css({"background-image":"url('image/graphUIRadio.png')"});
			$("#Exp_model .animate a:nth-of-type("+(modelNavStep+1)+")")
				.css({"background-image":"url('image/graphUIRadioActive.png')"});
		}
		modelNavPrevStep = modelNavStep;
	});
});